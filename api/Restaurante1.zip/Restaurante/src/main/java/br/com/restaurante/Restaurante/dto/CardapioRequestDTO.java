package br.com.restaurante.Restaurante.dto;

import br.com.restaurante.Restaurante.model.Prato;

public record CardapioRequestDTO (long id, String nome, String descricao, double preco) {

    public CardapioRequestDTO(Prato p){
        this(p.getId(), p.getNome(), p.getDescricao(), p.getPreco());
    }

}
