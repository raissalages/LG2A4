package br.com.restaurante.Restaurante.dto;

import br.com.restaurante.Restaurante.model.Prato;

public record CardapioResponseDTO(long id, String nome, String descricao, double preco) {
    public CardapioResponseDTO(Prato p){
        this(p.getId(), p.getNome(), p.getDescricao(), p.getPreco());
    }
}
/**
 * nao há setter (nao seta informação), mas nao precisa criar construtor
 * DTO serve pra passagem dos dados e nao pro armazenamento final
 * permite todos os getters dos dados (acesso encapsulado)
 */
