package br.com.restaurante.Restaurante.model;

import br.com.restaurante.Restaurante.dto.CardapioRequestDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import br.com.restaurante.Restaurante.dto.CardapioResponseDTO;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Prato {
    private long id;
    private String nome;
    private String descricao;
    private double preco;

    public Prato(CardapioRequestDTO data){
        this.id = data.id();
        this.nome = data.nome();
        this.descricao = data.descricao();
        this.preco = data.preco();

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
