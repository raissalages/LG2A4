package br.com.restaurante.Restaurante.dto;

import br.com.restaurante.Restaurante.model.Prato;

public record CardapioRemovalDTO(long id, String nome, String descricao, double preco) {

    public CardapioRemovalDTO(Prato p){
        this(p.getId(), p.getNome(), p.getDescricao(), p.getPreco());
    }

}
