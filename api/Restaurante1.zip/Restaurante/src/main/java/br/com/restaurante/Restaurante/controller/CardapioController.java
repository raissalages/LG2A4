package br.com.restaurante.Restaurante.controller;

import br.com.restaurante.Restaurante.dto.CardapioRemovalDTO;
import br.com.restaurante.Restaurante.dto.CardapioRequestDTO;
import br.com.restaurante.Restaurante.dto.CardapioResponseDTO;
import br.com.restaurante.Restaurante.model.Prato;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("cardapio")
public class CardapioController {
    private List<Prato> pratos = new ArrayList<>();

    @GetMapping
    public List<CardapioResponseDTO> getList(){
        //pratos.add(new Prato(1, "nome", "descricao", 23));
        return pratos.stream().map(CardapioResponseDTO::new).toList();
    }

    @PostMapping
    public void addPrato(@RequestBody CardapioRequestDTO data){
        pratos.add(new Prato(data));
    }

    @DeleteMapping
    public void removePrato(long id){
        pratos.remove(id);

    }
}
