import java.io.IOException;

public class ClienteTeste2{


}
