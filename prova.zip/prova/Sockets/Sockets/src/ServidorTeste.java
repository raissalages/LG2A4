import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServidorTeste {

    private ServerSocket serverSocket;


    public ServidorTeste(ServerSocket serverSocket){
        this.serverSocket = serverSocket;
    }


    public void iniciar(){
        try{
            while(!serverSocket.isClosed()){


                Socket cliente = serverSocket.accept();
                System.out.println("Cliente conectado!");


                ClienteThread clienteThread = new ClienteThread(cliente);
                Thread thread = new Thread(clienteThread);

                thread.start();
/*
                PrintStream saida = new PrintStream(cliente.getOutputStream());
                while (true){
                    String mensagem = scanner.nextLine();
                    saida.println(mensagem);
                }*/
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    public void fechar(){
        try {
            if(serverSocket != null)
                serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(12345);
        ServidorTeste server = new ServidorTeste(serverSocket);


        server.iniciar();
    }

}
