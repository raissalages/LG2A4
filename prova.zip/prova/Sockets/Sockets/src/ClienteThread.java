import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class ClienteThread implements Runnable{
    private Socket cliente; // estabelece conexao entre cliente e servidor
    private BufferedReader reader ;
    private BufferedWriter writer;
    private String nomeCliente;
    /**
     * cliente.getInputStream(): Obtém o fluxo de entrada (input stream) associado ao socket cliente. Isso permite que
     * você leia dados que são enviados do servidor para o cliente através dessa conexão de socket.
     *
     * new InputStreamReader(cliente.getInputStream()): Cria um objeto InputStreamReader que atua como uma ponte entre
     * o fluxo de entrada do socket e o BufferedReader. Ele converte os bytes lidos do InputStream em caracteres
     * legíveis.
     *
     * new BufferedReader(new InputStreamReader(cliente.getInputStream())): Cria um objeto BufferedReader que utiliza
     * o InputStreamReader criado anteriormente. Isso permite ler linhas de texto completas do fluxo de entrada do
     * socket, tornando mais conveniente o processo de leitura de dados.*/

    private static ArrayList<ClienteThread> clienteThreads = new ArrayList<>(); // mandar mensagem pra varios clientes
    public ClienteThread(Socket cliente) throws IOException {

        try {
            this.cliente = cliente;
            this.writer = new BufferedWriter(new OutputStreamWriter(cliente.getOutputStream())); // escreve o output, mostra o que ele ta recebendo
            this.reader = new BufferedReader(new InputStreamReader(cliente.getInputStream())); // le o input, cliente esta lendo
            this.nomeCliente = reader.readLine();
            clienteThreads.add(this);
            enviarMensagem("SERVIDOR: " + nomeCliente + " entrou no chat.");
        } catch (IOException e) {
            fechar(cliente, reader, writer);
        }

   }

   public void enviarMensagem(String mensagem){
       for (ClienteThread clienteThread: clienteThreads) {
           try{
               if(!clienteThread.nomeCliente.equals(nomeCliente)){
                   clienteThread.writer.write(mensagem);
                   clienteThread.writer.newLine(); // para de esperar mensagem quando pressiona o enter
                   clienteThread.writer.flush(); // limpar buffer antes mesmo de estar cheio
               }
           } catch (IOException e) {
               fechar(cliente, reader, writer);
           }

       }
   }

   public void desconectarCliente(){
        clienteThreads.remove(this);
        enviarMensagem("SERVIDOR: " + nomeCliente + " saiu do chat.");
   }
   public void fechar(Socket cliente, BufferedReader reader, BufferedWriter writer){
        desconectarCliente();
       try {
           if(reader != null)
               reader.close();

           if(writer != null)
                writer.close();

           if(cliente != null) // fecha reader e writer
               cliente.close();

       } catch (IOException e) {
            e.printStackTrace();
       }

   }
    @Override
    public void run() {
        String mensagemDoCliente;
        while(cliente.isConnected()){
            try {
                mensagemDoCliente = reader.readLine();
                enviarMensagem(mensagemDoCliente);

            } catch (IOException e) {
                fechar(cliente, reader, writer);
                break;
            }
        }
    }
}
