import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClienteTeste{
    private Socket cliente;
    private BufferedReader reader;
    private BufferedWriter writer;
    private String nomeCliente;

    public ClienteTeste(Socket cliente, String nomeCliente) throws IOException {
        try{this.cliente = cliente;
            this.writer = new BufferedWriter(new OutputStreamWriter(cliente.getOutputStream())); // escreve o output, mostra o que ele ta recebendo
            this.reader = new BufferedReader(new InputStreamReader(cliente.getInputStream())); // le o input, cliente esta lendo
            this.nomeCliente = nomeCliente;}
        catch (IOException e){
            fechar(cliente, reader, writer);
        }


    }

    public void enviarMensagem(){
        try {
            writer.write(nomeCliente);
            writer.newLine();
            writer.flush();

            Scanner scanner = new Scanner(System.in);

            while(cliente.isConnected()){
                String mensagem = scanner.nextLine();
                writer.write(nomeCliente + ": " + mensagem);
                writer.newLine();
                writer.flush();
            }
        } catch (IOException e) {
            fechar(cliente, reader, writer);
        }
    }

    public void escutarMensagem(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String mensagemDoGrupo;

                while(cliente.isConnected()){
                    try {
                        mensagemDoGrupo = reader.readLine();
                        System.out.println(mensagemDoGrupo);
                    }catch (IOException e){
                        fechar(cliente, reader, writer);

                    }
                }
            }
        }).start();
    }

    public void fechar(Socket cliente, BufferedReader reader, BufferedWriter writer){
        try {
            if(reader != null)
                reader.close();

            if(writer != null)
                writer.close();

            if(cliente != null) // fecha reader e writer
                cliente.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite seu nome de usuário: ");
        String nomeCliente = scanner.nextLine();
        Socket socket = new Socket("localhost", 12345);
        ClienteTeste cliente = new ClienteTeste(socket, nomeCliente);

        cliente.escutarMensagem();
        cliente.enviarMensagem();

    }
}
