/*
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public abstract class ClienteReferencia {

    Scanner scanner = new Scanner(System.in);
    Socket cliente;

    public ClienteReferencia(String host, int porta) throws IOException {
        cliente = new Socket(host, porta);
        ClienteThread clienteThread = new ClienteThread(cliente);
        clienteThread.start();
    }

    public void enviarMensagem() {
        try {
            PrintStream saida = new PrintStream(cliente.getOutputStream());
            while (true){
                String mensagem = scanner.nextLine();
                saida.println(mensagem);
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }


}
*/