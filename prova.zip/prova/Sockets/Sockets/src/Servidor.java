import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Servidor {
    public static void main(String[] args) {/*
        try {
            ServerSocket socket = new ServerSocket(12345);
            System.out.println("Servidor ativo ouvindo a porta 12345!");

            Socket cliente = socket.accept();
            System.out.println("Cliente conectado!");

            Scanner scanner = new Scanner(System.in);

            ClienteThread clienteThread = new ClienteThread(cliente);
            clienteThread.start();

            PrintStream saida = new PrintStream(cliente.getOutputStream());
            while (true){
                String mensagem = scanner.nextLine();
                saida.println(mensagem);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}