import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {/*
    public static void main(String[] args) {
        try {
            Socket cliente = new Socket("localhost", 12345);
            Scanner scanner = new Scanner(System.in);

            ClienteThread clienteThread = new ClienteThread(cliente);
            clienteThread.start();

            PrintStream saida = new PrintStream(cliente.getOutputStream());
            while (true){
                String mensagem = scanner.nextLine();
                saida.println(mensagem);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}
