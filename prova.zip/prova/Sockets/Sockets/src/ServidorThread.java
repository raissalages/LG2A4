import java.net.ServerSocket;

public class ServidorThread {
    private ServerSocket servidor;

}
