package main;

import java.util.ArrayList;
import java.util.List;

public class Admin extends Cliente {

    private static String usuario = "admin";
    private static String senha = "admin123";

    public Admin() {
        this.setNome("nome do admin");
        this.usuario = "admin";
        this.senha = "admin123";

    }

    public void adicionarAtividade(String nome, String data, String hora){
        Atividade atividade = new Atividade(nome, data, hora);
        atividade.getAtividades().add(atividade);


    }

    // No método removerAtividade da classe Admin
    public void removerAtividade(Long id) {
        // Crie uma cópia da lista de atividades
        List<Atividade> copiaAtividades = new ArrayList<>(Atividade.getAtividades());

        // Itere sobre a cópia e remova a atividade desejada
        for (Atividade atividade : copiaAtividades) {
            if (id.equals(atividade.getId())) {
                Atividade.getAtividades().remove(atividade);
            }
        }
    }
}
