package main;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import main.Admin;

import java.io.IOException;

@WebServlet("/AdicionarAtividadeServlet")
public class AdicionarAtividadeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nome = request.getParameter("nome");
        String data = request.getParameter("data");
        String hora = request.getParameter("hora");

        // Verifique se nome, data e hora não são nulos ou vazios antes de chamar o método
        if (nome != null && !nome.isEmpty() && data != null && !data.isEmpty() && hora != null && !hora.isEmpty()) {
            Admin admin = new Admin(); // Crie uma instância da classe Admin
            admin.adicionarAtividade(nome, data, hora); // Chame o método adicionarAtividade
        }

        // Redirecione para uma página de confirmação ou outra página apropriada
        response.sendRedirect("confirmacao.jsp");
    }
}
