package main;

public class Servlet {
}
