package main;

import java.util.ArrayList;

public class Atividade {


    private Long id;
    private static Long proximoId = 1L;

    private String nomeAtividade;
    private String data;
    private String horario;


    private ArrayList<Cliente> clientesInscritos = new ArrayList<Cliente>();

    private static ArrayList<Atividade> atividades = new ArrayList<Atividade>();


    public Atividade(String nomeAtividade, String data, String horario) {
        this.nomeAtividade = nomeAtividade;
        this.data = data;
        this.horario = horario;
        this.id = gerarNovoId();
    }

    private synchronized Long gerarNovoId() {
        return proximoId++;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getNomeAtividade() {
        return nomeAtividade;
    }

    public void setNomeAtividade(String nomeAtividade) {
        this.nomeAtividade = nomeAtividade;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
    public static ArrayList<Atividade> getAtividades() {
        return atividades;
    }

    public void setAtividades(ArrayList<Atividade> atividades) {
        this.atividades = atividades;
    }

    public ArrayList<Cliente> getClientesInscritos() {
        return clientesInscritos;
    }

    public void setClientesInscritos(ArrayList<Cliente> clientesInscritos) {
        this.clientesInscritos = clientesInscritos;
    }


    public static void exibirTodasAtividades(){
        for (Atividade atividade: Atividade.getAtividades()
        ) {
            System.out.println(atividade.getNomeAtividade());
            System.out.println(atividade.getData());
            System.out.println(atividade.getHorario());
        }
    }

    public void exibeAtividade(){
        System.out.println(this.getNomeAtividade());
        System.out.println(this.getData());
        System.out.println(this.getHorario());

    }

    public static void exibirIDAtividades(){
        for (Atividade atividade: Atividade.getAtividades()
        ) {
            System.out.println(atividade.getId());
            System.out.println(atividade.getNomeAtividade());
            System.out.println(atividade.getData());
            System.out.println(atividade.getHorario());
        }
    }
}
