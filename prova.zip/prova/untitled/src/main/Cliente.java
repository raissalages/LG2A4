package main;

import java.util.ArrayList;
import java.util.List;

public class Cliente {


    private String nome;
    private String usuario;
    private String senha;
    private ArrayList<Atividade> atividadesInscritas = new ArrayList<Atividade>();

    private static ArrayList<Cliente> clientes = new ArrayList<>();

    public Cliente() {
    }

    public Cliente(String nome, String usuario, String senha) {
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public ArrayList<Atividade> getAtividadesInscritas() {
        return atividadesInscritas;
    }

    public void setAtividadesInscritas(ArrayList<Atividade> atividadesInscritas) {
        this.atividadesInscritas = atividadesInscritas;
    }

    public static ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public static void setClientes(ArrayList<Cliente> clientes) {
        Cliente.clientes = clientes;
    }
    public void exibirEventosInscritos(){
        for (Atividade atividade: atividadesInscritas) {
            atividade.exibeAtividade();
        }
    }

    public void realizarInscricao(Long id){
        for (Atividade atividade: Atividade.getAtividades()){
            if(id.equals(atividade.getId())) {
                atividade.getClientesInscritos().add(this);
                atividadesInscritas.remove(atividade);
            }
        }
    }

    public void cancelarInscricao(Long id){
        for (Atividade atividade: atividadesInscritas){
            if(id.equals(atividade.getId())) {
                atividade.getClientesInscritos().remove(this);
                atividadesInscritas.remove(atividade);
            }
        }
    }

    public static boolean validaUsuario(String usuario){
        if(Cliente.getClientes() != null && !Cliente.getClientes().isEmpty()){
        for (Cliente cliente : Cliente.getClientes()) {
                if(cliente.getUsuario().equals(usuario))
                    return false;
            }
        }
        return true;
    }
}
