package restaurante.dto;

import java.util.List;

public record FuncionarioRequestDTO(String nome, String cpf) {
}

