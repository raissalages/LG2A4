package restaurante.dto;

public record CardapioRequestDTO(String titulo, String descricao, Double preco) {
}
