JSP & Servlets Demo
===================

This is a basic shopping cart application utilizing JSPs and servlets as well as an in-memory H2 embedded database.

If interested, please see the [JSP & Servlets Demo Page](http://chrisbaileydeveloper.com/projects/jsp-servlets-demo-page/) on my website where I briefly discuss the application.

